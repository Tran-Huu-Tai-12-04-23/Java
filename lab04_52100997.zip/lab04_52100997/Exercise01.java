public class Exercise01 {
    public static void main(String[] args) {
        Point2D po1 = new Point2D();
        Point2D po2 = new Point2D(2.3123123123f ,2.612312321321f);

        System.out.println(po1.getX());
        System.out.println(po1.getY());
        System.out.println(po1);
        

        System.out.println(po2.getX());
        System.out.println(po2.getY());
        System.out.println(po2);
    }
}
